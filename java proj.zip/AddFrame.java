import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class AddFrame extends JFrame
{
Container c;
JLabel lblRno,lblName;
JTextField txtRno,txtName;
JButton btnSave,btnBack;

AddFrame()
{
c=getContentPane();
c.setLayout(new FlowLayout());
lblRno = new JLabel("Enter Roll No");
txtRno = new JTextField(20);
lblName = new JLabel("Enter Name");
txtName = new JTextField(20);
btnSave=new JButton("Save");
btnBack=new JButton("Back");


c.add(lblRno);
c.add(txtRno);
c.add(lblName);
c.add(txtName);
c.add(btnSave);
c.add(btnBack);


btnBack.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent ae){
MainFrame mf = new MainFrame();
dispose();
}
});

btnSave.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent ae){
try{
	String test="";
	String rno=txtRno.getText();
	String name=txtName.getText();
	//System.out.println(test);
	String[] t=name.split("\\d");
	for(String s:t)
		test=test.concat(s);
	System.out.println(test+"\t"+name);
	if(test == null && test.isEmpty()){
		throw new NumberFormatException();
	}
	if(!test.equals(name)){
		throw new NumberFormatException();
	}
	else{	
		DbHandler db=new DbHandler();
		db.addStudent(Integer.parseInt(rno),name);
	}

}
catch(NumberFormatException nfe){
JOptionPane.showMessageDialog(new JDialog(),"Enter valid details");	
}
}
});

setSize(350,300);
setTitle("Add Frame");
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setLocationRelativeTo(null);
setVisible(true);
}
}