import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class DeleteFrame extends JFrame
{
Container c;
JLabel lblRno;
JTextField txtRno;
JButton btnDelete,btnBack;

DeleteFrame()
{
c=getContentPane();
c.setLayout(new FlowLayout());
lblRno = new JLabel("Enter Roll No");
txtRno = new JTextField(20);
btnDelete=new JButton("Delete");
btnBack=new JButton("Back");

c.add(lblRno);
c.add(txtRno);
c.add(btnDelete);
c.add(btnBack);

btnBack.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent ae){
MainFrame mf = new MainFrame();
dispose();
}
});

btnDelete.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent ae){
try{
String rno=txtRno.getText();
if(Integer.parseInt(rno)>0 && rno.matches("[0-9]+"))
{	
	DbHandler db=new DbHandler();
	db.deleteStudent(Integer.parseInt(rno));

}
else
{
JOptionPane.showMessageDialog(new JDialog(),"Enter valid details");
}
}
catch(NumberFormatException nfe){
JOptionPane.showMessageDialog(new JDialog(),"Enter valid details");	
}

}});


setSize(300,300);
setTitle("Add Frame");
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setLocationRelativeTo(null);
setVisible(true);
}
}