import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class UpdateFrame extends JFrame
{
Container c;
JLabel lblRno,lblName;
JTextField txtRno,txtName;
JButton btnUpdate,btnBack;

UpdateFrame()
{
c=getContentPane();
c.setLayout(new FlowLayout());
lblRno = new JLabel("Enter Roll No");
txtRno = new JTextField(20);
lblName = new JLabel("Enter New Name");
txtName = new JTextField(20);
btnUpdate=new JButton("Update");
btnBack=new JButton("Back");


c.add(lblRno);
c.add(txtRno);
c.add(lblName);
c.add(txtName);
c.add(btnUpdate);
c.add(btnBack);

btnBack.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent ae){
MainFrame mf = new MainFrame();
dispose();
}
});

btnUpdate.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent ae){
String rno=txtRno.getText();
String name=txtName.getText();
DbHandler db=new DbHandler();
try{
if(!rno.matches("[0-9]+")){
	JOptionPane.showMessageDialog(new JDialog(),"Enter valid rollno details");
	throw new NumberFormatException();
}

if(!name.matches("[a-zA-Z_]+")){
JOptionPane.showMessageDialog(new JDialog(),"Enter valid name details");
throw new NumberFormatException();
}
db.updateStudent(Integer.parseInt(rno),name);
}
catch(Exception e){
	txtName.setText("");
	txtName.requestFocus();
	System.out.println("Handled");
}
}
});

setSize(300,300);
setTitle("Update Frame");
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setLocationRelativeTo(null);
setVisible(true);

}

}