import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ViewFrame extends JFrame
{
Container c;
TextArea txtdis;
JButton btnBack;

ViewFrame()
{
c=getContentPane();
c.setLayout(new FlowLayout());
txtdis = new TextArea(10,30);
txtdis.setEditable(false);
btnBack=new JButton("Back");

c.add(txtdis);
c.add(btnBack);

btnBack.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent ae){
MainFrame mf = new MainFrame();
dispose();
}
});

DbHandler db=new DbHandler();
String data=db.viewStudent();
txtdis.setText(data);

setSize(300,300);
setTitle("View Frame");
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setLocationRelativeTo(null);
setVisible(true);

}
}